#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void stoneVanillaMain() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}


// Skyblock: private approved native dialog slices. All ordinary text keeps vanilla behavior.
uniform sampler2D Sampler0;
float stoneX(float x, float width) {
    if (x <= 48.0) return x * 0.5;
    if (x >= 1232.0) return width - (1280.0 - x) * 0.5;
    return 24.0 + (width - 48.0) * (x - 48.0) / 1184.0;
}
float stoneY(float y, float height) {
    if (y <= 48.0) return y * 0.5;
    if (y >= 680.0) return height - (720.0 - y) * 0.5;
    return 24.0 + (height - 44.0) * (y - 48.0) / 632.0;
}
vec4 stoneRect(int piece) {
    float x[9] = float[9](0.0,48.0,246.0,444.0,642.0,840.0,1036.0,1232.0,1280.0);
    float y[4] = float[4](48.0,259.0,470.0,680.0);
    if (piece < 8) return vec4(x[piece],0.0,x[piece+1]-x[piece],48.0);
    if (piece < 11) { int i=piece-8; return vec4(0.0,y[i],48.0,y[i+1]-y[i]); }
    if (piece == 11) return vec4(48.0,48.0,1184.0,632.0);
    if (piece < 15) { int i=piece-12; return vec4(1232.0,y[i],48.0,y[i+1]-y[i]); }
    int i=piece-15; return vec4(x[i],680.0,x[i+1]-x[i],40.0);
}
void stoneBackdrop() {
    if (abs(ProjMat[3][3]-1.0)>0.01 || Color.a<0.99 || any(lessThan(Color.rgb,vec3(0.999)))) return;
    ivec2 atlas=textureSize(Sampler0,0);
    ivec3 tag=ivec3(round(texelFetch(Sampler0,ivec2(floor(UV0*vec2(atlas))),0).rgb*255.0));
    if (tag.r!=31 || tag.g!=89 || tag.b<128 || tag.b>219) return;
    int piece=(tag.b-128)/4, index=(tag.b-128)%4;
    vec2 corner=vec2(index>=2?1.0:0.0,index==1||index==2?1.0:0.0);
    vec4 source=stoneRect(piece);
    vec2 raster=piece==11?vec2(1.0):source.zw;
    ivec2 originPixel=ivec2(floor(UV0*vec2(atlas)))-ivec2(corner*(raster+vec2(1.0)));
    ivec2 extent=ivec2(raster)+ivec2(2);
    if (any(lessThan(originPixel,ivec2(0))) || any(greaterThan(originPixel+extent,atlas))) return;
    // All four private corner tags must agree; unrelated artwork with one matching color is untouched.
    for (int k=0;k<4;k++) {
        ivec2 c=ivec2(k>=2?extent.x-1:0,k==1||k==2?extent.y-1:0);
        ivec4 actual=ivec4(round(texelFetch(Sampler0,originPixel+c,0)*255.0));
        if (any(notEqual(actual,ivec4(31,89,128+piece*4+k,255)))) return;
    }
    vec2 uvOrigin=UV0-corner*(raster+vec2(1.98))/vec2(atlas);
    texCoord0=uvOrigin+(vec2(1.0)+corner*(raster-vec2(0.02)))/vec2(atlas);
    vec2 screen=vec2(round(2.0/ProjMat[0][0]),round(-2.0/ProjMat[1][1]));
    vec2 p=source.xy+corner*source.zw;
    vec2 target=vec2(stoneX(p.x,screen.x),stoneY(p.y,screen.y));
    gl_Position.xy=vec2(target.x*2.0/screen.x-1.0,1.0-target.y*2.0/screen.y)*gl_Position.w;
    vertexColor=vec4(1.0);
    #if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance=0.0;
    cylindricalVertexDistance=0.0;
    #endif
}

void main(){stoneVanillaMain();stoneBackdrop();}
