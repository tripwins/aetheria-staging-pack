#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void aetheria_native_main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}

#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;
void aetheria_tool_motion() {
    ivec3 channels=ivec3(round(Color.rgb*255.0));
    float w=float(channels.b),h=float(channels.g),padding=float(channels.r);
    if(w<16.0 || w>240.0 || h<16.0 || h>padding || padding>240.0) return;
    ivec2 pixels=textureSize(Sampler0,0);
    ivec3 tag=ivec3(round(texelFetch(Sampler0,ivec2(floor(UV0*vec2(pixels))),0).rgb*255.0));
    if(tag.r!=19 || tag.g!=87 || tag.b<240 || tag.b>243) return;
    int index=tag.b-240;
    vec2 corner=vec2(index>=2?1.0:0.0,index==1||index==2?1.0:0.0);
    vec2 extent=vec2(w,padding),size=vec2(w,h);
    vec2 origin=Position.xy-corner*extent;
    vec2 uvOrigin=UV0-corner*(extent-vec2(0.02))/vec2(pixels);
    texCoord0=uvOrigin+(vec2(1.0)+corner*(size-vec2(2.02)))/vec2(pixels);
    float seconds=GameTime*1200.0;
    float angle=sin(seconds*1.3+origin.x*0.013)*0.045;
    mat2 turn=mat2(cos(angle),sin(angle),-sin(angle),cos(angle));
    vec2 local=turn*(corner*size-size*0.5)+size*0.5;
    local.y+=sin(seconds*1.8+origin.x*0.015)*1.2;
    gl_Position=ProjMat*ModelViewMat*vec4(origin+local,Position.z,1.0);
    vertexColor=vec4(1.0);
}

void main(){aetheria_native_main();aetheria_tool_motion();}
