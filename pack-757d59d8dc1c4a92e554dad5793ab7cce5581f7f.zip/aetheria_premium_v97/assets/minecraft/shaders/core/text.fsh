#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void aetheria_native_main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}

#include <minecraft:globals.glsl>

#ifndef OIT_ALPHA_ONLY

layout(location = 4) noperspective in vec2 aetheriaUV;
layout(location = 5) flat in vec2 aetheriaSize;
layout(location = 6) flat in vec3 aetheriaTint;
layout(location = 7) flat in float aetheriaType;

bool aetheria_fragment() {
    if (aetheriaType < 0.5) return false;
    if (aetheriaType > 1.5 && aetheriaType < 2.5) {
        if (aetheriaUV.y < 1.0 / 17.0) discard;
        return false;
    }
    vec2 p = aetheriaUV * aetheriaSize;
    float seconds = GameTime * 1200.0;
    vec3 tint = aetheriaTint;
    float alpha = 0.0;
    if (aetheriaType < 1.5) {
        float edge = min(min(p.x, p.y), min(aetheriaSize.x-p.x, aetheriaSize.y-p.y));
        float border = 1.0 - smoothstep(0.6, 1.45, edge);
        float sweep = exp(-pow((p.x + p.y * 0.45 - mod(seconds * 33.0, aetheriaSize.x + aetheriaSize.y + 36.0)) / 13.0, 2.0));
        alpha = 0.045 + border * (0.62 + 0.14 * sin(seconds * 3.0)) + sweep * 0.10;
        tint = mix(tint, vec3(1.0), sweep * 0.35);
    } else {
        // Four slow, sparse motes. Overlay only, not a complete screen redraw.
        for (int i=0; i<4; i++) {
            float seed = float(i);
            vec2 point = vec2(fract(seed * 0.317 + 0.11) * aetheriaSize.x,
                aetheriaSize.y - mod(seconds * (3.0 + seed) + seed * 27.0, aetheriaSize.y));
            float glow = exp(-dot(p-point,p-point) / 1.7);
            alpha += glow * (0.15 + 0.08 * sin(seconds * 1.6 + seed));
        }
        tint = vec3(1.0,0.83,0.43);
    }
    if (alpha < 0.006) discard;
    fragColor = vec4(tint, min(alpha,0.92));
    return true;
}

#endif

void main() {
#ifndef OIT_ALPHA_ONLY
 if (aetheria_fragment()) return;
#endif
 aetheria_native_main(); }
