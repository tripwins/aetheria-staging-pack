#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void aetheria_native_main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}

#include <minecraft:globals.glsl>

uniform sampler2D Sampler0;
layout(location = 4) noperspective out vec2 aetheriaUV;
layout(location = 5) flat out vec2 aetheriaSize;
layout(location = 6) flat out vec3 aetheriaTint;
layout(location = 7) flat out float aetheriaType;

void aetheria_effect() {
    aetheriaType = 0.0;
    aetheriaUV = vec2(0.0);
    aetheriaSize = vec2(1.0);
    aetheriaTint = vec3(1.0);
    int index = gl_VertexIndex % 4;
    vec2 corner = vec2(index >= 2 ? 1.0 : 0.0, index == 1 || index == 2 ? 1.0 : 0.0);
    ivec2 texturePixels = textureSize(Sampler0, 0);
    ivec2 pixel = ivec2(round(UV0 * vec2(texturePixels))) - ivec2(corner);
    ivec3 signature = ivec3(round(texelFetch(Sampler0, pixel, 0).rgb * 255.0));
    bool marker = signature.r == 19 && signature.g == 87 && signature.b >= 200 && signature.b <= 204;
    bool tool = false;
    if (!marker) {
        pixel = ivec2(round(UV0 * vec2(texturePixels))) - ivec2(corner * vec2(16.0, 17.0));
        signature = ivec3(round(texelFetch(Sampler0, pixel, 0).rgb * 255.0));
        tool = all(equal(signature, ivec3(19, 87, 205)));
    }
    if (!marker && !tool) return;
    ivec3 channels = ivec3(round(Color.rgb * 255.0));
    int data = (channels.r << 16) | (channels.g << 8) | channels.b;
    vec2 offset = vec2(float(data & 127) * 4.0, float((data >> 7) & 31) * 9.0);
    vec2 size = vec2(float(((data >> 12) & 127) + 1) * 4.0, float(((data >> 19) & 31) + 1) * 9.0);
    if (offset.x + size.x > 288.0 || offset.y + size.y > 180.0) return;
    vec2 screen = vec2(round(2.0 / ProjMat[0][0]), round(-2.0 / ProjMat[1][1]));
    // Native HeaderAndFooterLayout puts a fitting body at min(header+30,bottom-height).
    vec2 origin = vec2(float(max(0, int(screen.x) - 318) / 2 + 15), min(63.0, screen.y - 193.0) + 4.0);
    vec2 local = corner * size;
    float seconds = GameTime * 1200.0;
    if (tool) {
        float angle = sin(seconds * 1.3 + offset.x * 0.013) * 0.075;
        mat2 turn = mat2(cos(angle), sin(angle), -sin(angle), cos(angle));
        local = turn * (local - size * 0.5) + size * 0.5;
        local.y += sin(seconds * 1.8 + offset.x * 0.015) * 1.5;
        aetheriaType = 2.0;
    } else {
        aetheriaType = signature.b == 204 ? 3.0 : 1.0;
    }
    vec2 position = origin + offset + local;
    gl_Position.xy = vec2(position.x * 2.0 / screen.x - 1.0, 1.0 - position.y * 2.0 / screen.y) * gl_Position.w;
    aetheriaUV = corner;
    aetheriaSize = size;
    aetheriaTint = signature.b == 200 ? vec3(1.0, 0.79, 0.30)
        : signature.b == 201 ? vec3(0.39, 0.83, 0.70)
        : signature.b == 202 ? vec3(0.43, 0.73, 1.0)
        : vec3(0.93, 0.47, 0.43);
    vertexColor = vec4(1.0);
}

void main() { aetheria_native_main(); aetheria_effect(); }
